package com.example.mealsuggestion_app_assignment_1_st10035636

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var daytime by remember {
                mutableStateOf("")
            }

            var suggestedmeal by remember {
                mutableStateOf("")
            }

            Column (
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxSize()
            ) {
                Text(
                    text = "Meal Suggestion App",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.size(30.dp))

                OutlinedTextField(
                    value = daytime,
                    onValueChange = {text ->
                        daytime = text
                    },
                    placeHolder = {
                        Text(text = "Enter time of day")
                    }
                )

                Spacer(modifier = Modifier.size(30.dp))

                Row {
                    Button(onClick = {
                        suggestedmeal = when(daytime) {
                        "Morning" -> "Cereal and Coffee"
                            "Mid-Morning" -> "Tea and Toasted Chicken & Mayo Sandwich"
                            "Mid-day" -> "Burger & Chips"
                            "Afternoon" -> "A fruit"
                            "Dinner" -> "Chicken Ala-king"
                            else -> "Invalid day entered. Please try again using one of the following options: 'Morning','Mid-Morning', 'Mid-day', 'Afternoon', 'Dinner'."
                    }
                    }) {
                        Text(text = "Suggest")
                    }
                    Button(onClick = {
                        daytime = ""
                        suggestedmeal = ""
                    }) {
                        Text(text = "Reset")
                    }
                }

                Text(text = "Meal Suggestion for $daytime is:")
                Text(text = suggestedmeal)
            }
        }
    }
}